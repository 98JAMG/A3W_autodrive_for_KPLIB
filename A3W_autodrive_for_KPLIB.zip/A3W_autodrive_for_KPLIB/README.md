Adaptation of wasteland's automatic driver for kp liberation

1. include autodriver\CfgFunctions.hpp in the CfgFunctions of description.ext
2. copy onPlayerKilled.sqf and autodriver folder in the mission
3. open functions\fn_addActionsPlayer.sqf and add the code in the end
4. open scripts\client\init_client.sqf and add the code after player addEventHandler HandleRating