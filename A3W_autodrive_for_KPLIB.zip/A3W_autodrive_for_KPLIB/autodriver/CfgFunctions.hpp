class AUTD
{
	class functions
	{
		file = "autodriver";
		class disableDriverAssist {};
		class driverAssistEngineOff {};
		class driverAssistEngineOn {};
		class driverAssistLightsOff {};
		class driverAssistLightsOn {};
		class enableDriverAssist {};
		class getOutVehicle {};
		class addManagedAction {};
	};
};